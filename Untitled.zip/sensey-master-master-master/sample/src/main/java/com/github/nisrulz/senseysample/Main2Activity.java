package com.github.nisrulz.senseysample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void display(View view) {
        EditText edit1 = (EditText)findViewById(R.id.e1);
        EditText edit2 = (EditText)findViewById(R.id.e2);

        if ( (edit1.getText().toString().trim().equals("")) || (edit2.getText().toString().trim().equals("")) ) {
            Toast.makeText(getApplicationContext(), "Enter Details", Toast.LENGTH_SHORT).show();


        }
        else {
            Intent i = new Intent(Main2Activity.this, MainActivity.class);
            startActivity(i);
        }
    }
}
